import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import Morse from './components/morse/Morse';


function App() {

  return (
    <div className="App">
      <Morse/>
      <img src={logo} className="App-logo" alt="logo" />
    </div>
  );
}

export default App;
